package Teste;

import Page.Metodo;
import Page.Teste;
import io.cucumber.java.es.Dado;
import io.cucumber.java.it.Quando;
import io.cucumber.java.pt.Então;

public class Steps {

	Metodo metodo = new Metodo();
	Teste teste = new Teste();

	@Dado("que eu esteja no {string}")
	public void que_eu_esteja_no(String site) {
		metodo.abrirNavegador("CHROME", site);
	}

	@Quando("cadastrar novos usuario")
	public void cadastrar_novos_usuario() throws InterruptedException {
		teste.Realizar();
	}

	@Então("valido as informações")
	public void valido_as_informações() {
		metodo.fecharNavegador();
	}

	}
