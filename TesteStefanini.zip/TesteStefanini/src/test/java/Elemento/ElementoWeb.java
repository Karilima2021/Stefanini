package Elemento;

import org.openqa.selenium.By;

public class ElementoWeb {

	private By nome = By.id("name");
	private By email = By.id("email");
	private By senha = By.id("password");
	private By Cadastrar = By.id("register");

	public By getnome() {
		return nome;

	}

	public By getemail() {
		return email;

	}

	public By getsenha() {
		return senha;

	}

	public By getCadastrar() {
		return Cadastrar;

	}

}
