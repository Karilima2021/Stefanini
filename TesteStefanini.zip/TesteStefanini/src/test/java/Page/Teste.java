package Page;

import Elemento.ElementoWeb;

public class Teste {
	Metodo metodos = new Metodo();
	ElementoWeb el = new ElementoWeb();

	public void Realizar() throws InterruptedException {

		// preencher Name
		metodos.preencher(el.getnome(), "Maitê Adriana da Rocha");
		Thread.sleep(3000);

		// preencher email
		metodos.preencher(el.getemail(), "maiteadrianadarocha@live.com");
		Thread.sleep(3000);

		// preencher senha
		metodos.preencher(el.getsenha(), "9ccSI29rEb");
		Thread.sleep(3000);

		// clicar no botão cadastrar
		metodos.click(el.getCadastrar());

		Thread.sleep(3000);

	}

}
